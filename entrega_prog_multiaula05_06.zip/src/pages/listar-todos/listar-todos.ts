import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Chamado } from '../../model/chamado';

/**
 * Generated class for the ListarTodosPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-listar-todos',
  templateUrl: 'listar-todos.html',
})
export class ListarTodosPage {
  public chamados: Chamado[];
  
  constructor(public navCtrl: NavController, public navParams: NavParams) {


    
    this.chamados = [];

    let c1 = {id: 1134, categoria:'HardWare', descricao:'Mouse quebrou', status:'Fechado'};
    let c3 = {id: 1212,categoria:'HardWare', descricao:'Monitor não liga', status:'Fechado'};
    let c2 = {id: 1154,categoria:'Software', descricao:'Microsoft Word não abre', status:'Fechado'};
    let c4 = {id: 1166,categoria:'Rede', descricao:'Computador não conecta à internet', status:'Fechado'};

    this.chamados = [c1, c2, c3, c4];

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ListarTodosPage');
  }

}
