import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ListarAbertosPage } from './listar-abertos';

@NgModule({
  declarations: [
    ListarAbertosPage,
  ],
  imports: [
    IonicPageModule.forChild(ListarAbertosPage),
  ],
})
export class ListarAbertosPageModule {}
