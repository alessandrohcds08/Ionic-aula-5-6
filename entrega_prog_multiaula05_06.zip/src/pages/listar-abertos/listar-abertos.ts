import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Chamado } from '../../model/chamado';

/**
 * Generated class for the ListarAbertosPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-listar-abertos',
  templateUrl: 'listar-abertos.html',
})
export class ListarAbertosPage {

  public chamados: Chamado[];

  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.chamados = [];

    let a1 = {id: 1134, categoria:'SoftWare', descricao:'Chrome bugado', status:'Aberto'};
    let a3 = {id: 1212,categoria:'Rede', descricao:'Google não abre', status:'aberto'};
    let a2 = {id: 1154,categoria:'Software', descricao:'Microsoft Excel não abre', status:'aberto'};
    let a4 = {id: 1166,categoria:'HardWare', descricao:'Computador explodiu', status:'aberto'};

    this.chamados = [a1, a2, a3, a4];




  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ListarAbertosPage');
  }

}
