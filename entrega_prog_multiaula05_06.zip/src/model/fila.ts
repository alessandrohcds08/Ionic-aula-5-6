export interface Fila
{
    categoria: string;


}